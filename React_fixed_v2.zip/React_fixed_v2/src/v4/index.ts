import z4 from "./classic/index.js";
export * from "./classic/index.js";

export default z4;
